<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "auth";

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $code  = $_POST['code'];

    // Vérifier si le code correspond
    $stmt = $conn->prepare("SELECT verification_code FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user['verification_code'] == $code) {
        // Marquer comme vérifié
        $update = $conn->prepare("UPDATE users SET is_verified=1 WHERE email=?");
        $update->execute([$email]);

        header('Location: index.php');
        exit();

        echo "<p style='color:green;'>Email vérifié avec succès !</p>";
    } else {
        echo "<p style='color:red;'>Code invalide. Veuillez réessayer.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification par email</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="container">
        <h2>Vérification Email</h2>
        <form method="POST" class="checking">
            <label>Code de vérification :</label><br>
            <div class="input-group">
                    <input type="text" name="code" placeholder="Entrez le code ..." required><br>
                </div>
            <input class="hiddeninput" type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>"><br>
            <button type="submit" class='btn'>Vérifier</button>
        </form>
    </div>
    
    
</body>
</html>

